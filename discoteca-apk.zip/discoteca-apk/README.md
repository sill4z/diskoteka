# DISKOTEKA: projeto para gerar o APK

Esta pasta contém o app pronto (`www/index.html`) e a configuração do Capacitor, que embala o site como app Android.
Os álbuns ficam salvos no próprio aparelho. Desinstalar o app apaga a coleção.

## O que você precisa instalar (uma vez)

1. Node.js (versão LTS): https://nodejs.org
2. Android Studio: https://developer.android.com/studio (na primeira abertura, deixe ele instalar o Android SDK)

## Passo a passo

Abra um terminal dentro desta pasta e rode:

    npm install @capacitor/core @capacitor/cli @capacitor/android
    npm install -D @capacitor/assets
    npx cap add android
    npx @capacitor/assets generate --android
    npx cap sync android
    npx cap open android

No Android Studio, espere o Gradle terminar de sincronizar e vá em:

    Build > Build Bundle(s) / APK(s) > Build APK(s)

O arquivo sai em `android/app/build/outputs/apk/debug/app-debug.apk`.
Copie para o celular e instale (o Android pede para permitir instalar de fontes desconhecidas).

## Para mudar o app depois

Edite `www/index.html` e rode `npx cap sync android` antes de gerar o APK de novo.

## Observações

- Ao adicionar um álbum, basta colar o link do Spotify: título, artista, data e capa são lidos das informações públicas do link (sem API nem chave). Para isso o app precisa de internet. Tudo pode ser editado depois, no menu que aparece ao segurar o álbum.
- Na grade, tocar na capa abre o álbum no Spotify. Segurar a capa abre o menu (ouvir, marcar como ouvido, editar, remover). Começar a tocar sozinho depende do Spotify.
- As fontes são as do sistema do celular.
- O APK de debug serve para uso pessoal. Para publicar na Play Store é preciso gerar um pacote assinado (Build > Generate Signed Bundle / APK).

## Gerar o APK pelo GitHub (sem instalar nada)

1. Crie um repositório no GitHub.
2. Extraia o conteúdo desta pasta (`diskoteka-apk`) e envie todos os arquivos e pastas para a raiz do repositório. É importante incluir a pasta `.github/workflows`.
3. Abra a aba **Actions** e selecione **Build APK**. O workflow também roda automaticamente quando você enviar alterações.
4. Ao terminar, abra a execução concluída e baixe o artefato **DISKOTEKA-apk**. Dentro dele estará o `app-debug.apk`.

O workflow instala o Capacitor, cria o projeto Android e compila o APK de debug automaticamente.

## Backup da coleção

O backup exportado é um arquivo JSON e não inclui imagens de capa. Na importação, o app consulta novamente cada álbum no Spotify para recuperar a capa. Você pode escolher mesclar o backup com a coleção atual ou substituí-la. A recuperação das capas depende de conexão com a internet e da disponibilidade dos dados públicos do Spotify.
